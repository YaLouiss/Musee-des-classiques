pip install -r requirements.txt
py main.py
pause